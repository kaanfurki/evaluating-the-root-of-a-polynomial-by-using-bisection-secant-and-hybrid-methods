Kaan Icer 2017401072

*My project evaluates the root of a polynomial (f(x)=0) by using
bisection, secant and hybrid methods.

*You should first compile .cpp file to create .exe file.
(you will compile kaanicer.cpp and by doing that you generate kaanicer.exe)

*You should use command prompt to run the code.

*How to use command prompt?
     1) you need to reach the file kaanicer.exe, on prompt you should go 
        where this file is. (e.g. if the file is located on desktop,
        you need to go desktop etc.)
     2) when you reach the location, you need to write the file name and
        inputs like this (in other saying your commands should be like this):
        kaanicer.exe 2 2 -7 1 -7 1.5 1.8 0.001
	(kaanicer.exe is file name, 2 2 -7 1 -7 are the coefficients, 
	1.5(x_0) and 1.8(x_1) are initial guesses (x_1>x_0) and 
	0.001 is the tolerance value. 
	Program will solve 2*x^4 + 2*x^3 − 7*x^2 + x − 7 = 0 and find
	the root.
     3) then you need to run the code. You will see the outputs on the
	command prompt. Outputs will be like this:
	
	For the Bisection Method: 9 number of iterations and 1.66934 is the root.
	For the Secant Method: 4 number of iterations and 1.66941 is the root.
	For the Hybrid Method: 5 number of iterations and 1.66941 is the root.

