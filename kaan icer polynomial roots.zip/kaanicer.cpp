#include<iostream>
#include<fstream>
#include<new>
#include<string>
#include<stdlib.h>
#include<math.h>
#include<cmath>
using namespace std;
double absolute_value(double p){ // this function returns the absolute value of a number.
	if(p<0){
		p=(-1)*p;
	}
	else{
		p=p;
	}
	return p;
}
double polynom_calculator(double *coefficients, int size, double x){ //this function calculates the polynom.
	double sum=0, number;
	for(int i=0; i<size-1; i++){
		number=x;
		for(int j=0; j<size-i-2; j++){
			number=number*x;
		}
		number=coefficients[i]*number;
		sum=sum+number;
	}
	sum=sum+coefficients[size-1];
	return sum;
}
int main(int argc, char* argv[]){
	int size, bisection_num=0, secant_num=0, hybrid_num=0;//bisection_num is the iteration number for bisection method,
	//secant_num is the iteration number for secant method, hybrid_num is the iteration number for hybrid method.
	size=argc-4; // size is the polynomial's degree.
	double *coefficients, x_0, x_1, tolerance_value, old_x, the_oldest, new_x, bisection_x, secant_x, hybrid_x; //coefficients is the coefficients of the polynomial.
	// x_0 and x_1 are initial guesses. old_x, the_oldest, new_x are numbers which are used in calculations to solve 3rd root.
	//bisection_x is the root found by bisection method, secant_x is the root found by secant method, hybrid_x is the root found by hybrid method.
	coefficients=new double [size];
	for(int i=0; i<size; i++){
		coefficients[i]=atof(argv[i+1]); //converts strings to double.
	}
	x_0=atof(argv[size+1]);//converts string to double.
	x_1=atof(argv[size+2]);//converts string to double.
	tolerance_value=atof(argv[size+3]);//converts string to double.
	
	old_x=x_1;
	the_oldest=x_0;
	while(tolerance_value<(absolute_value(old_x-the_oldest))){ //bisection method starts.
		new_x= the_oldest+((old_x-the_oldest)/2);
		if((polynom_calculator(coefficients,size,the_oldest)<=0)&&(polynom_calculator(coefficients, size, new_x)<=0)){ //sign checking part.
		
			the_oldest=new_x;	
		}
		else if((polynom_calculator(coefficients,size,the_oldest)>0)&&(polynom_calculator(coefficients, size, new_x)>0)){ //sign checking part.
			the_oldest=new_x;
		}
		else{ 
			old_x=new_x;
		}
		bisection_num++;
	}
	bisection_x=new_x;
	
	old_x=x_1;
	the_oldest=x_0;
	do{ //secant method starts.
		new_x=old_x-(polynom_calculator(coefficients,size,old_x)*((old_x-the_oldest)/(polynom_calculator(coefficients,size,old_x)-polynom_calculator(coefficients,size,the_oldest))));
		the_oldest=old_x;
		old_x=new_x;
		secant_num++;		
	}while(tolerance_value<(absolute_value(old_x-the_oldest)));
	secant_x=new_x;
	
	int hybrid_bisection_num=0, hybrid_secant_num=0; //hybrid_bisection_num is bisection method iteration number used in hybrid method.
	//hybrid_secant_num is secant method number used in hybrid method.
	old_x=x_1;
	the_oldest=x_0;
	while(tolerance_value<(absolute_value(old_x-the_oldest))&&hybrid_bisection_num<2){ //hybrid method starts. (2 iteration with bisection method)
		new_x= the_oldest+((old_x-the_oldest)/2);
		if((polynom_calculator(coefficients,size,the_oldest)<=0)&&(polynom_calculator(coefficients, size, new_x)<=0)){
			the_oldest=new_x;	
		}
		else{
			old_x=new_x;
		}
		hybrid_bisection_num++;
	}
	do{ //hybrid method continues. (iterations with second method)
		new_x=old_x-(polynom_calculator(coefficients,size,old_x)*((old_x-the_oldest)/(polynom_calculator(coefficients,size,old_x)-polynom_calculator(coefficients,size,the_oldest))));
		the_oldest=old_x;
		old_x=new_x;
		hybrid_secant_num++;		
	}while(tolerance_value<(absolute_value(old_x-the_oldest)));
	hybrid_x=new_x;
	hybrid_num=hybrid_bisection_num+hybrid_secant_num;
	
	cout<<"For the Bisection Method: "<<bisection_num<<" number of iterations and "<<bisection_x<<" is the root."<<endl;
	cout<<"For the Secant Method: "<<secant_num<<" number of iterations and "<<secant_x<<" is the root."<<endl;
	cout<<"For the Hybrid Method: "<<hybrid_num<<" number of iterations and "<<hybrid_x<<" is the root."<<endl;
	delete []coefficients; //to avoid memory loss, i deleted coefficients array.
	return 0;
	
}
